<?php
$servername = "localhost";

$username = "macinbfg_denique";
$password = "denique@123";
$database = "macinbfg_deniqueadmin";


// Create connection
$conn = new mysqli($servername,$username, $password,$database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//echo "Connected successfully";


?>

